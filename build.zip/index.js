// import './src/index.ts'
// @ts-ignore
import './lib/index.js'
